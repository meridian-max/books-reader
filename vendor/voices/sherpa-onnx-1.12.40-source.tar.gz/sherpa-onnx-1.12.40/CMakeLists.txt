if (CMAKE_VERSION VERSION_GREATER_EQUAL "4.0.0")
  set(CMAKE_POLICY_VERSION_MINIMUM 3.10)
endif()

cmake_minimum_required(VERSION 3.15 FATAL_ERROR)

# https://cmake.org/cmake/help/latest/prop_tgt/MSVC_RUNTIME_LIBRARY.html
cmake_policy(SET CMP0091 NEW)

if(POLICY CMP0169)
  cmake_policy(SET CMP0169 OLD)
  set(CMAKE_POLICY_DEFAULT_CMP0169 OLD)
endif()

if(POLICY CMP0177)
  cmake_policy(SET CMP0177 NEW)
endif()

message(STATUS "CMake version: ${CMAKE_VERSION}")

set(CMAKE_OSX_DEPLOYMENT_TARGET "10.14" CACHE STRING "Minimum OS X deployment version. Used only for macOS")

set(CMAKE_POLICY_DEFAULT_CMP0063 NEW)
set(CMAKE_POLICY_DEFAULT_CMP0069 NEW)

project(sherpa-onnx)

# Remember to update
# ./CHANGELOG.md
# ./new-release.sh
set(SHERPA_ONNX_VERSION "1.12.40")

# Disable warning about
#
# "The DOWNLOAD_EXTRACT_TIMESTAMP option was not given and policy CMP0135 is
#  not set.
if (CMAKE_VERSION VERSION_GREATER_EQUAL "3.24.0")
  cmake_policy(SET CMP0135 NEW)
endif()


if(CMAKE_SOURCE_DIR STREQUAL CMAKE_CURRENT_SOURCE_DIR)
  set(SUGGEST_BUILD_BINARIES ON)
else()
  set(SUGGEST_BUILD_BINARIES OFF)
endif()

option(SHERPA_ONNX_ENABLE_PYTHON "Whether to build Python" OFF)
option(SHERPA_ONNX_ENABLE_TESTS "Whether to build tests" OFF)
option(SHERPA_ONNX_ENABLE_CHECK "Whether to build with assert" OFF)
option(BUILD_SHARED_LIBS "Whether to build shared libraries" OFF)
option(SHERPA_ONNX_ENABLE_PORTAUDIO "Whether to build with portaudio" ON)
option(SHERPA_ONNX_ENABLE_JNI "Whether to build JNI internface" OFF)
option(SHERPA_ONNX_ENABLE_C_API "Whether to build C API" ON)
option(SHERPA_ONNX_ENABLE_WEBSOCKET "Whether to build webscoket server/client" ON)
option(SHERPA_ONNX_ENABLE_GPU "Enable ONNX Runtime GPU support" OFF)
option(SHERPA_ONNX_ENABLE_DIRECTML "Enable ONNX Runtime DirectML support" OFF)
option(SHERPA_ONNX_LINK_D3D "Whether static ONNX runtime lib with DML" OFF)

option(SHERPA_ONNX_ENABLE_WASM "Whether to enable WASM" OFF)
option(SHERPA_ONNX_ENABLE_WASM_SPEAKER_DIARIZATION "Whether to enable WASM for speaker diarization" OFF)
option(SHERPA_ONNX_ENABLE_WASM_TTS "Whether to enable WASM for TTS" OFF)
option(SHERPA_ONNX_ENABLE_WASM_ASR "Whether to enable WASM for ASR" OFF)
option(SHERPA_ONNX_ENABLE_WASM_KWS "Whether to enable WASM for KWS" OFF)
option(SHERPA_ONNX_ENABLE_WASM_VAD "Whether to enable WASM for VAD" OFF)
option(SHERPA_ONNX_ENABLE_WASM_VAD_ASR "Whether to enable WASM for VAD+ASR" OFF)
option(SHERPA_ONNX_ENABLE_WASM_NODEJS "Whether to enable WASM for NodeJS" OFF)
option(SHERPA_ONNX_ENABLE_WASM_SPEECH_ENHANCEMENT "Whether to enable WASM for speech enhancement" OFF)
option(SHERPA_ONNX_ENABLE_BINARY "Whether to build binaries" ${SUGGEST_BUILD_BINARIES})
option(SHERPA_ONNX_ENABLE_TTS "Whether to build TTS related code" ON)
option(SHERPA_ONNX_ENABLE_SPEAKER_DIARIZATION "Whether to build speaker diarization related code" ON)
option(SHERPA_ONNX_LINK_LIBSTDCPP_STATICALLY "True to link libstdc++ statically. Used only when BUILD_SHARED_LIBS is OFF on Linux" ON)
option(SHERPA_ONNX_USE_PRE_INSTALLED_ONNXRUNTIME_IF_AVAILABLE "True to use pre-installed onnxruntime if available" ON)
option(SHERPA_ONNX_ENABLE_SANITIZER "Whether to enable ubsan and asan" OFF)
option(SHERPA_ONNX_BUILD_C_API_EXAMPLES "Whether to enable C API examples" ${SUGGEST_BUILD_BINARIES})
option(SHERPA_ONNX_ENABLE_RKNN "Whether to build for RKNN NPU " OFF)
option(SHERPA_ONNX_ENABLE_AXERA "Whether to build for Axera NPU " OFF)
option(SHERPA_ONNX_ENABLE_AXCL "Whether to build for Axcl NPU " OFF)
option(SHERPA_ONNX_ENABLE_ASCEND_NPU "Whether to build for Ascend NPU " OFF)
option(SHERPA_ONNX_ENABLE_QNN "Whether to build for Qualcomm NPU" OFF)
option(SHERPA_ONNX_ENABLE_SPACEMIT "Whether to build for SpacemiT CPUs " OFF)
set(SHERPA_ONNX_LINUX_ARM64_GPU_ONNXRUNTIME_VERSION "1.11.0" CACHE STRING "Used only for Linux ARM64 GPU. Set to 1.11.0 if you use CUDA 10.2 and cudnn8. Set it to 1.16.0 if you use CUDA 11.4 and cudnn8. Set it to 1.18.0 if you use CUDA 12.2 and cudnn8. Set it to 1.18.1 if you use CUDA 12.6 and cudnn9")

# SHERPA_ONNX_USE_STATIC_CRT controls whether we use:
#   - Static CRT:   /MT  (Release), /MTd (Debug)
#   - Dynamic CRT:  /MD  (Release), /MDd (Debug)
option(SHERPA_ONNX_USE_STATIC_CRT "For Windows only. ON to use static CRT (/MT /MTd); OFF to use dynamic (/MD /MDd)" ON)


# On Windows with MSVC, explicitly control which C runtime (CRT) to use.
#
# We rely on CMAKE_MSVC_RUNTIME_LIBRARY (CMake >= 3.15) instead of manually
# appending /MT, /MTd, /MD, or /MDd to compiler flags.
#
# Benefits:
#   - Correct behavior for multi-config generators (Visual Studio, Ninja Multi-Config)
#   - No reliance on CMAKE_BUILD_TYPE (which is empty for multi-config generators)
#   - Cleaner interaction with subprojects and FetchContent dependencies
#
# The generator expression automatically selects:
#   - Debug   -> /MTd or /MDd
#   - Release -> /MT  or /MD
#   - RelWithDebInfo / MinSizeRel -> /MT or /MD
if (MSVC AND NOT DEFINED CMAKE_MSVC_RUNTIME_LIBRARY)
  if(DEFINED CMAKE_BUILD_TYPE AND NOT CMAKE_BUILD_TYPE STREQUAL "")
    if (SHERPA_ONNX_USE_STATIC_CRT)
      # Use static CRT: /MT (Release) and /MTd (Debug)
      if(CMAKE_BUILD_TYPE MATCHES Debug)
        set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreadedDebug")
      else()
        set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded")
      endif()
    else()
      # Use dynamic CRT: /MD (Release) and /MDd (Debug)
      if(CMAKE_BUILD_TYPE MATCHES Debug)
        set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreadedDebugDLL")
      else()
        set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreadedDLL")
      endif()
    endif()
  else()
    if (SHERPA_ONNX_USE_STATIC_CRT)
      # Use static CRT: /MT (Release) and /MTd (Debug)
      set(CMAKE_MSVC_RUNTIME_LIBRARY
          "MultiThreaded$<$<CONFIG:Debug>:Debug>")
    else()
      # Use dynamic CRT: /MD (Release) and /MDd (Debug)
      set(CMAKE_MSVC_RUNTIME_LIBRARY
          "MultiThreadedDLL$<$<CONFIG:Debug>:Debug>")
    endif()
  endif()
endif()

set(CMAKE_ARCHIVE_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/lib")
set(CMAKE_LIBRARY_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/lib")
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")

if(UNIX)
  set(CMAKE_SKIP_BUILD_RPATH FALSE)
  set(BUILD_RPATH_USE_ORIGIN TRUE)
  set(CMAKE_INSTALL_RPATH_USE_LINK_PATH TRUE)
endif()

if(NOT APPLE)
  set(SHERPA_ONNX_RPATH_ORIGIN "$ORIGIN")
else()
  set(SHERPA_ONNX_RPATH_ORIGIN "@loader_path")
endif()

if(UNIX)
  set(CMAKE_INSTALL_RPATH ${SHERPA_ONNX_RPATH_ORIGIN})
  set(CMAKE_BUILD_RPATH ${SHERPA_ONNX_RPATH_ORIGIN})
endif()

if(NOT CMAKE_BUILD_TYPE)
  message(STATUS "No CMAKE_BUILD_TYPE given, default to Release")
  set(CMAKE_BUILD_TYPE Release)
endif()

set(CMAKE_EXPORT_COMPILE_COMMANDS ON CACHE BOOL "")

if(DEFINED ANDROID_ABI AND NOT SHERPA_ONNX_ENABLE_JNI AND NOT SHERPA_ONNX_ENABLE_C_API)
  message(STATUS "Set SHERPA_ONNX_ENABLE_JNI to ON for Android")
  set(SHERPA_ONNX_ENABLE_JNI ON CACHE BOOL "" FORCE)
endif()

if(SHERPA_ONNX_ENABLE_PYTHON AND NOT BUILD_SHARED_LIBS)
  message(STATUS "Set BUILD_SHARED_LIBS to ON since SHERPA_ONNX_ENABLE_PYTHON is ON")
  set(BUILD_SHARED_LIBS ON CACHE BOOL "" FORCE)
endif()

if(SHERPA_ONNX_ENABLE_GPU)
  message(WARNING "\
Compiling for NVIDIA GPU is enabled. Please make sure cudatoolkit
is installed on your system. Otherwise, you will get errors at runtime.
Hint: You don't need sudo permission to install CUDA toolkit. Please refer to
  https://k2-fsa.github.io/k2/installation/cuda-cudnn.html
to install CUDA toolkit if you have not installed it.")
  if(NOT BUILD_SHARED_LIBS)
    message(STATUS "Set BUILD_SHARED_LIBS to ON since SHERPA_ONNX_ENABLE_GPU is ON")
    set(BUILD_SHARED_LIBS ON CACHE BOOL "" FORCE)
  endif()
endif()

if(SHERPA_ONNX_ENABLE_DIRECTML)
  message(WARNING "\
Compiling with DirectML enabled. Please make sure Windows 10 SDK
is installed on your system. Otherwise, you will get errors at runtime.
Please refer to
  https://onnxruntime.ai/docs/execution-providers/DirectML-ExecutionProvider.html#requirements
to install Windows 10 SDK if you have not installed it.")
  if(NOT BUILD_SHARED_LIBS)
    message(STATUS "Set BUILD_SHARED_LIBS to ON since SHERPA_ONNX_ENABLE_DIRECTML is ON")
    set(BUILD_SHARED_LIBS ON CACHE BOOL "" FORCE)
  endif()
endif()

if(CMAKE_SYSTEM_NAME STREQUAL OHOS)
  set(CMAKE_CXX_FLAGS "-Wno-unused-command-line-argument ${CMAKE_CXX_FLAGS}")
  set(CMAKE_C_FLAGS "-Wno-unused-command-line-argument ${CMAKE_C_FLAGS}")
endif()

if(ANDROID)
  # see https://github.com/microsoft/onnxruntime/pull/22076
  # https://github.com/k2-fsa/sherpa-onnx/issues/2413
  set(CMAKE_SHARED_LINKER_FLAGS "${CMAKE_SHARED_LINKER_FLAGS} -Wl,-z,max-page-size=16384")
endif()

message(STATUS "CMAKE_BUILD_TYPE: ${CMAKE_BUILD_TYPE}")
message(STATUS "CMAKE_INSTALL_PREFIX: ${CMAKE_INSTALL_PREFIX}")
message(STATUS "BUILD_SHARED_LIBS ${BUILD_SHARED_LIBS}")
message(STATUS "SHERPA_ONNX_ENABLE_PYTHON ${SHERPA_ONNX_ENABLE_PYTHON}")
message(STATUS "SHERPA_ONNX_ENABLE_TESTS ${SHERPA_ONNX_ENABLE_TESTS}")
message(STATUS "SHERPA_ONNX_ENABLE_CHECK ${SHERPA_ONNX_ENABLE_CHECK}")
message(STATUS "SHERPA_ONNX_ENABLE_PORTAUDIO ${SHERPA_ONNX_ENABLE_PORTAUDIO}")
message(STATUS "SHERPA_ONNX_ENABLE_JNI ${SHERPA_ONNX_ENABLE_JNI}")
message(STATUS "SHERPA_ONNX_ENABLE_C_API ${SHERPA_ONNX_ENABLE_C_API}")
message(STATUS "SHERPA_ONNX_ENABLE_WEBSOCKET ${SHERPA_ONNX_ENABLE_WEBSOCKET}")
message(STATUS "SHERPA_ONNX_ENABLE_GPU ${SHERPA_ONNX_ENABLE_GPU}")
message(STATUS "SHERPA_ONNX_ENABLE_WASM ${SHERPA_ONNX_ENABLE_WASM}")
message(STATUS "SHERPA_ONNX_ENABLE_WASM_SPEAKER_DIARIZATION ${SHERPA_ONNX_ENABLE_WASM_SPEAKER_DIARIZATION}")
message(STATUS "SHERPA_ONNX_ENABLE_WASM_TTS ${SHERPA_ONNX_ENABLE_WASM_TTS}")
message(STATUS "SHERPA_ONNX_ENABLE_WASM_ASR ${SHERPA_ONNX_ENABLE_WASM_ASR}")
message(STATUS "SHERPA_ONNX_ENABLE_WASM_KWS ${SHERPA_ONNX_ENABLE_WASM_KWS}")
message(STATUS "SHERPA_ONNX_ENABLE_WASM_VAD ${SHERPA_ONNX_ENABLE_WASM_VAD}")
message(STATUS "SHERPA_ONNX_ENABLE_WASM_VAD_ASR ${SHERPA_ONNX_ENABLE_WASM_VAD_ASR}")
message(STATUS "SHERPA_ONNX_ENABLE_WASM_NODEJS ${SHERPA_ONNX_ENABLE_WASM_NODEJS}")
message(STATUS "SHERPA_ONNX_ENABLE_WASM_SPEECH_ENHANCEMENT ${SHERPA_ONNX_ENABLE_WASM_SPEECH_ENHANCEMENT}")
message(STATUS "SHERPA_ONNX_ENABLE_BINARY ${SHERPA_ONNX_ENABLE_BINARY}")
message(STATUS "SHERPA_ONNX_ENABLE_TTS ${SHERPA_ONNX_ENABLE_TTS}")
message(STATUS "SHERPA_ONNX_ENABLE_SPEAKER_DIARIZATION ${SHERPA_ONNX_ENABLE_SPEAKER_DIARIZATION}")
message(STATUS "SHERPA_ONNX_LINK_LIBSTDCPP_STATICALLY ${SHERPA_ONNX_LINK_LIBSTDCPP_STATICALLY}")
message(STATUS "SHERPA_ONNX_USE_PRE_INSTALLED_ONNXRUNTIME_IF_AVAILABLE ${SHERPA_ONNX_USE_PRE_INSTALLED_ONNXRUNTIME_IF_AVAILABLE}")
message(STATUS "SHERPA_ONNX_ENABLE_SANITIZER: ${SHERPA_ONNX_ENABLE_SANITIZER}")
message(STATUS "SHERPA_ONNX_BUILD_C_API_EXAMPLES: ${SHERPA_ONNX_BUILD_C_API_EXAMPLES}")
message(STATUS "SHERPA_ONNX_ENABLE_RKNN: ${SHERPA_ONNX_ENABLE_RKNN}")
message(STATUS "SHERPA_ONNX_ENABLE_AXERA: ${SHERPA_ONNX_ENABLE_AXERA}")
message(STATUS "SHERPA_ONNX_ENABLE_AXCL: ${SHERPA_ONNX_ENABLE_AXCL}")
message(STATUS "SHERPA_ONNX_ENABLE_ASCEND_NPU: ${SHERPA_ONNX_ENABLE_ASCEND_NPU}")
message(STATUS "SHERPA_ONNX_ENABLE_QNN: ${SHERPA_ONNX_ENABLE_QNN}")
message(STATUS "SHERPA_ONNX_ENABLE_SPACEMIT: ${SHERPA_ONNX_ENABLE_SPACEMIT}")
message(STATUS "SHERPA_ONNX_LINK_D3D: ${SHERPA_ONNX_LINK_D3D}")
message(STATUS "SHERPA_ONNX_USE_STATIC_CRT: ${SHERPA_ONNX_USE_STATIC_CRT}")
if(MSVC)
  message(STATUS "CMAKE_MSVC_RUNTIME_LIBRARY ${CMAKE_MSVC_RUNTIME_LIBRARY}")
endif()

if(BUILD_SHARED_LIBS OR SHERPA_ONNX_ENABLE_JNI)
  set(CMAKE_CXX_VISIBILITY_PRESET hidden)
  set(CMAKE_VISIBILITY_INLINES_HIDDEN 1)
endif()

# Rust on Linux links static sherpa-onnx archives into PIE executables by
# default, so static objects need PIC as well.
if(NOT WIN32)
  set(CMAKE_POSITION_INDEPENDENT_CODE ON)
endif()

if(BUILD_SHARED_LIBS AND NOT CMAKE_SYSTEM_NAME STREQUAL iOS AND CMAKE_BUILD_TYPE STREQUAL Release)
  # Don't use LTO for iOS since it causes the following error
  # error: unable to find any architecture information in the binary
  # at '/Users/fangjun/open-source/sherpa-onnx/build-ios/build/os64/sherpa-onnx.a':
  # Unknown header: 0xb17c0de
  # See also https://forums.developer.apple.com/forums/thread/714324

  include(CheckIPOSupported)
  check_ipo_supported(RESULT ipo)
  if(ipo)
    message(STATUS "IPO is enabled")
    set(CMAKE_INTERPROCEDURAL_OPTIMIZATION ON)
  else()
    message(STATUS "IPO is not available")
  endif()
endif()

if(SHERPA_ONNX_ENABLE_TTS)
  message(STATUS "TTS is enabled")
  add_definitions(-DSHERPA_ONNX_ENABLE_TTS=1)
else()
  message(STATUS "TTS is disabled")
  add_definitions(-DSHERPA_ONNX_ENABLE_TTS=0)
endif()

if(SHERPA_ONNX_ENABLE_SPEAKER_DIARIZATION)
  message(STATUS "speaker diarization is enabled")
  add_definitions(-DSHERPA_ONNX_ENABLE_SPEAKER_DIARIZATION=1)
else()
  message(STATUS "speaker diarization is disabled")
  add_definitions(-DSHERPA_ONNX_ENABLE_SPEAKER_DIARIZATION=0)
endif()

if(SHERPA_ONNX_ENABLE_DIRECTML)
  message(STATUS "DirectML is enabled")
  add_definitions(-DSHERPA_ONNX_ENABLE_DIRECTML=1)
else()
  message(STATUS "DirectML is disabled")
  add_definitions(-DSHERPA_ONNX_ENABLE_DIRECTML=0)
endif()

if(SHERPA_ONNX_ENABLE_WASM_SPEAKER_DIARIZATION)
  if(NOT SHERPA_ONNX_ENABLE_SPEAKER_DIARIZATION)
    message(FATAL_ERROR "Please set SHERPA_ONNX_ENABLE_SPEAKER_DIARIZATION to ON if you want to build WASM for speaker diarization")
  endif()

  if(NOT SHERPA_ONNX_ENABLE_WASM)
    message(FATAL_ERROR "Please set SHERPA_ONNX_ENABLE_WASM to ON if you enable WASM for speaker diarization")
  endif()
endif()

if(SHERPA_ONNX_ENABLE_WASM_TTS)
  if(NOT SHERPA_ONNX_ENABLE_TTS)
    message(FATAL_ERROR "Please set SHERPA_ONNX_ENABLE_TTS to ON if you want to build WASM for TTS")
  endif()

  if(NOT SHERPA_ONNX_ENABLE_WASM)
    message(FATAL_ERROR "Please set SHERPA_ONNX_ENABLE_WASM to ON if you enable WASM for TTS")
  endif()
endif()

if(SHERPA_ONNX_ENABLE_WASM_ASR)
  if(NOT SHERPA_ONNX_ENABLE_WASM)
    message(FATAL_ERROR "Please set SHERPA_ONNX_ENABLE_WASM to ON if you enable WASM for ASR")
  endif()
endif()

if(SHERPA_ONNX_ENABLE_WASM_NODEJS)
  if(NOT SHERPA_ONNX_ENABLE_WASM)
    message(FATAL_ERROR "Please set SHERPA_ONNX_ENABLE_WASM to ON if you enable WASM for NodeJS")
  endif()
  add_definitions(-DSHERPA_ONNX_ENABLE_WASM_KWS=1)
endif()

if(SHERPA_ONNX_ENABLE_WASM)
  add_definitions(-DSHERPA_ONNX_ENABLE_WASM=1)
endif()

if(SHERPA_ONNX_ENABLE_WASM_KWS)
  if(NOT SHERPA_ONNX_ENABLE_WASM)
    message(FATAL_ERROR "Please set SHERPA_ONNX_ENABLE_WASM to ON if you enable WASM for KWS")
  endif()
  add_definitions(-DSHERPA_ONNX_ENABLE_WASM_KWS=1)
endif()

if(SHERPA_ONNX_ENABLE_WASM_VAD)
  if(NOT SHERPA_ONNX_ENABLE_WASM)
    message(FATAL_ERROR "Please set SHERPA_ONNX_ENABLE_WASM to ON if you enable WASM for VAD")
  endif()
endif()

if(SHERPA_ONNX_ENABLE_WASM_VAD_ASR)
  if(NOT SHERPA_ONNX_ENABLE_WASM)
    message(FATAL_ERROR "Please set SHERPA_ONNX_ENABLE_WASM to ON if you enable WASM for VAD+ASR")
  endif()
endif()

if(SHERPA_ONNX_ENABLE_WASM_SPEECH_ENHANCEMENT)
  if(NOT SHERPA_ONNX_ENABLE_WASM)
    message(FATAL_ERROR "Please set SHERPA_ONNX_ENABLE_WASM to ON if you enable WASM for speech enhancement")
  endif()
endif()

if(NOT CMAKE_CXX_STANDARD)
  set(CMAKE_CXX_STANDARD 17 CACHE STRING "The C++ version to be used.")
endif()
set(CMAKE_CXX_EXTENSIONS OFF)
message(STATUS "C++ Standard version: ${CMAKE_CXX_STANDARD}")

include(CheckIncludeFileCXX)

if(SHERPA_ONNX_ENABLE_RKNN)
  add_definitions(-DSHERPA_ONNX_ENABLE_RKNN=1)
endif()

if(SHERPA_ONNX_ENABLE_AXERA)
  add_definitions(-DSHERPA_ONNX_ENABLE_AXERA=1)
endif()

if(SHERPA_ONNX_ENABLE_AXCL)
  add_definitions(-DSHERPA_ONNX_ENABLE_AXCL=1)
endif()

if(SHERPA_ONNX_ENABLE_QNN)
  add_definitions(-DSHERPA_ONNX_ENABLE_QNN=1)
endif()

if(SHERPA_ONNX_ENABLE_SPACEMIT)
  add_definitions(-DSHERPA_ONNX_ENABLE_SPACEMIT=1)
endif()

if(SHERPA_ONNX_ENABLE_ASCEND_NPU)
  set(ASCEND_TOOLKIT_HOME)
  if(NOT DEFINED ENV{ASCEND_TOOLKIT_HOME})
    if(EXISTS /usr/local/Ascend/ascend-toolkit/latest)
      set(ASCEND_TOOLKIT_HOME /usr/local/Ascend/ascend-toolkit/latest)
    else()
      message(FATAL_ERROR "\
      Please specify the installation directory of the ascend toolkit.
      For instance, if it is installed in

        /usr/local/Ascend/ascend-toolkit/latest

      You can run

        export ASCEND_TOOLKIT_HOME=/usr/local/Ascend/ascend-toolkit/latest
      ")
    endif()
  else()
    set(ASCEND_TOOLKIT_HOME $ENV{ASCEND_TOOLKIT_HOME})
  endif()

  message(STATUS "ASCEND_TOOLKIT_HOME: ${ASCEND_TOOLKIT_HOME}")

  if(NOT EXISTS ${ASCEND_TOOLKIT_HOME}/include/acl/acl.h)
    message(FATAL_ERROR "${ASCEND_TOOLKIT_HOME}/include/acl/acl.h does not exist")
  endif()

  if(NOT EXISTS ${ASCEND_TOOLKIT_HOME}/lib64/libascendcl.so)
    message(FATAL_ERROR "${ASCEND_TOOLKIT_HOME}/lib64/libascendcl.so does not exist")
  endif()

  add_definitions(-DSHERPA_ONNX_ENABLE_ASCEND_NPU=1)
  message(STATUS "Build with Ascend NPU")
endif()

if(SHERPA_ONNX_ENABLE_QNN)
  if(NOT DEFINED ENV{QNN_SDK_ROOT})
      message(FATAL_ERROR "\
      Please specify the installation directory of the QNN SDK toolkit.
      For instance, if it is installed in

        /mnt/sdb/open-source/qairt/2.33.0.250327

      You can run

        source /mnt/sdb/open-source/qairt/2.33.0.250327/bin/envsetup.sh

      which will give you the following output

      [INFO] AISW SDK environment set
      [INFO] QNN_SDK_ROOT: /mnt/sdb/open-source/qairt/2.33.0.250327
      [INFO] SNPE_ROOT: /mnt/sdb/open-source/qairt/2.33.0.250327

      Then run

        echo $QNN_SDK_ROOT

      It should print:

        /mnt/sdb/open-source/qairt/2.33.0.250327

      You can choose a version of QNN SDK by yourself. You don't need
      to use 2.33.0.250327
      ")
  endif()

  set(QNN_SDK_ROOT $ENV{QNN_SDK_ROOT})

  if(NOT EXISTS ${QNN_SDK_ROOT}/include/QNN/QnnInterface.h)
    message(FATAL_ERROR "${QNN_SDK_ROOT}/include/QNN/QnnInterface.h does not exist")
  endif()
endif()

if(UNIX AND NOT APPLE AND NOT SHERPA_ONNX_ENABLE_WASM AND NOT CMAKE_SYSTEM_NAME STREQUAL Android AND NOT CMAKE_SYSTEM_NAME STREQUAL OHOS)
  check_include_file_cxx(alsa/asoundlib.h SHERPA_ONNX_HAS_ALSA)
  if(SHERPA_ONNX_HAS_ALSA)
    message(STATUS "With Alsa")
    add_definitions(-DSHERPA_ONNX_ENABLE_ALSA=1)
  else()
    message(WARNING "\
Could not find alsa/asoundlib.h !
We won't build sherpa-onnx-alsa
To fix that, please do:
  (1) sudo apt-get install alsa-utils libasound2-dev pkg-config
  (2) rm -rf build
  (3) re-try
  ")
  endif()
endif()

check_include_file_cxx(cxxabi.h SHERPA_ONNX_HAVE_CXXABI_H)
check_include_file_cxx(execinfo.h SHERPA_ONNX_HAVE_EXECINFO_H)

if(WIN32)
  add_definitions(-DNOMINMAX) # Otherwise, std::max() and std::min() won't work
endif()


if(WIN32 AND MSVC)
  # disable various warnings for MSVC
  # 4244: 'return': conversion from 'unsigned __int64' to 'int', possible loss of data
  # 4267: 'initializing': conversion from 'size_t' to 'int', possible loss of data
  # 4305: 'argument': truncation from 'double' to 'const float'
  # 4334: '<<': result of 32-bit shift implicitly converted to 64 bits
  # 4800: 'int': forcing value to bool 'true' or 'false'
  # 4996: 'fopen': This function or variable may be unsafe
  set(disabled_warnings
      /wd4244
      /wd4267
      /wd4305
      /wd4334
      /wd4800
      /wd4996
  )
  message(STATUS "Disabled warnings: ${disabled_warnings}")
  foreach(w IN LISTS disabled_warnings)
    string(APPEND CMAKE_CXX_FLAGS " ${w} ")
  endforeach()

  add_compile_options("$<$<C_COMPILER_ID:MSVC>:/utf-8>")
  add_compile_options("$<$<CXX_COMPILER_ID:MSVC>:/utf-8>")
endif()

list(APPEND CMAKE_MODULE_PATH ${CMAKE_CURRENT_SOURCE_DIR}/cmake/Modules)
list(APPEND CMAKE_MODULE_PATH ${CMAKE_CURRENT_SOURCE_DIR}/cmake)

include(show-info)

if(SHERPA_ONNX_ENABLE_WASM)
  # Enable it for debugging in case there is something wrong.
  # string(APPEND CMAKE_CXX_FLAGS " -g4 -s ASSERTIONS=2 -s SAFE_HEAP=1 -s STACK_OVERFLOW_CHECK=1 ")
endif()

if(NOT BUILD_SHARED_LIBS AND CMAKE_SYSTEM_NAME STREQUAL Linux)
  if(SHERPA_ONNX_LINK_LIBSTDCPP_STATICALLY)
    message(STATUS "Link libstdc++ statically")
    set(CMAKE_CXX_FLAGS " ${CMAKE_CXX_FLAGS} -static-libstdc++ -static-libgcc ")
  else()
    message(STATUS "Link libstdc++ dynamically")
  endif()
endif()

if(SHERPA_ONNX_ENABLE_PYTHON)
  include(pybind11)
endif()

include(kaldi-native-fbank)
include(kaldi-decoder)
include(onnxruntime)
include(simple-sentencepiece)
set(ONNXRUNTIME_DIR ${onnxruntime_SOURCE_DIR})
message(STATUS "ONNXRUNTIME_DIR: ${ONNXRUNTIME_DIR}")

if(SHERPA_ONNX_ENABLE_PORTAUDIO AND SHERPA_ONNX_ENABLE_BINARY)
  # portaudio is used only in building demo binaries and the sherpa-onnx-core
  # library does not depend on it.
  include(portaudio)
endif()

if(SHERPA_ONNX_ENABLE_TESTS)
  enable_testing()
  include(googletest)
endif()

if(SHERPA_ONNX_ENABLE_WEBSOCKET)
  include(websocketpp)
  include(asio)
endif()

include(json)

if(SHERPA_ONNX_ENABLE_TTS)
  include(espeak-ng-for-piper)
  set(ESPEAK_NG_DIR ${espeak_ng_SOURCE_DIR})
  message(STATUS "ESPEAK_NG_DIR: ${ESPEAK_NG_DIR}")
  include(piper-phonemize)
endif()

if(SHERPA_ONNX_ENABLE_SPEAKER_DIARIZATION)
  include(hclust-cpp)
endif()

# if(NOT MSVC AND CMAKE_BUILD_TYPE STREQUAL Debug AND (CMAKE_CXX_COMPILER_ID STREQUAL "Clang" OR CMAKE_CXX_COMPILER_ID STREQUAL "AppleClang"))
if(SHERPA_ONNX_ENABLE_SANITIZER)
  message(WARNING "enable ubsan and asan")
  set(CMAKE_REQUIRED_LIBRARIES -lubsan -lasan)
  include(CheckCCompilerFlag)

  set(flags -fsanitize=undefined )
  string(APPEND flags " -fno-sanitize-recover=undefined ")
  string(APPEND flags " -fsanitize=integer ")
  string(APPEND flags " -fsanitize=nullability ")
  string(APPEND flags " -fsanitize=implicit-conversion ")
  string(APPEND flags " -fsanitize=bounds ")
  string(APPEND flags " -fsanitize=address ")

  if(OFF)
    set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} ${flags} -Wall -Wextra")
    set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} ${flags} -Wall -Wextra")
  else()
    set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} ${flags}")
    set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} ${flags}")
  endif()

  set(CMAKE_EXECUTABLE_LINKER_FLAGS "${CMAKE_EXECUTABLE_LINKER_FLAGS} ${flags}")

  add_compile_options(-fno-omit-frame-pointer)
endif()

add_subdirectory(sherpa-onnx)

if(SHERPA_ONNX_ENABLE_C_API AND SHERPA_ONNX_ENABLE_BINARY AND SHERPA_ONNX_BUILD_C_API_EXAMPLES)
  set(SHERPA_ONNX_PKG_WITH_CARGS "-lcargs")
  add_subdirectory(c-api-examples)
  add_subdirectory(cxx-api-examples)
endif()

if(SHERPA_ONNX_ENABLE_WASM)
  add_subdirectory(wasm)
endif()

message(STATUS "CMAKE_CXX_FLAGS: ${CMAKE_CXX_FLAGS}")

if(NOT BUILD_SHARED_LIBS)
  if(APPLE)
    set(SHERPA_ONNX_PKG_CONFIG_EXTRA_LIBS "-lc++ -framework Foundation")
  endif()

  if(UNIX AND NOT APPLE)
    set(SHERPA_ONNX_PKG_CONFIG_EXTRA_LIBS "-lstdc++ -lm -pthread -ldl")
  endif()
endif()

if(NOT BUILD_SHARED_LIBS)
# See https://people.freedesktop.org/~dbn/pkg-config-guide.html
  if(SHERPA_ONNX_ENABLE_TTS)
    configure_file(cmake/sherpa-onnx-static.pc.in ${PROJECT_BINARY_DIR}/sherpa-onnx.pc @ONLY)
  else()
    configure_file(cmake/sherpa-onnx-static-no-tts.pc.in ${PROJECT_BINARY_DIR}/sherpa-onnx.pc @ONLY)
  endif()
else()
  configure_file(cmake/sherpa-onnx-shared.pc.in ${PROJECT_BINARY_DIR}/sherpa-onnx.pc @ONLY)
endif()

install(
  FILES
    ${PROJECT_BINARY_DIR}/sherpa-onnx.pc
  DESTINATION
    .
)
message(STATUS "CMAKE_CXX_FLAGS: ${CMAKE_CXX_FLAGS}")
