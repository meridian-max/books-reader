include_directories(${PROJECT_SOURCE_DIR})

add_executable(streaming-zipformer-cxx-api ./streaming-zipformer-cxx-api.cc)
target_link_libraries(streaming-zipformer-cxx-api sherpa-onnx-cxx-api)

add_executable(streaming-zipformer-with-hr-cxx-api ./streaming-zipformer-with-hr-cxx-api.cc)
target_link_libraries(streaming-zipformer-with-hr-cxx-api sherpa-onnx-cxx-api)

add_executable(speech-enhancement-gtcrn-cxx-api ./speech-enhancement-gtcrn-cxx-api.cc)
target_link_libraries(speech-enhancement-gtcrn-cxx-api sherpa-onnx-cxx-api)

add_executable(source-separation-spleeter-cxx-api ./source-separation-spleeter-cxx-api.cc)
target_link_libraries(source-separation-spleeter-cxx-api sherpa-onnx-cxx-api)

add_executable(source-separation-uvr-cxx-api ./source-separation-uvr-cxx-api.cc)
target_link_libraries(source-separation-uvr-cxx-api sherpa-onnx-cxx-api)

add_executable(speech-enhancement-dpdfnet-cxx-api ./speech-enhancement-dpdfnet-cxx-api.cc)
target_link_libraries(speech-enhancement-dpdfnet-cxx-api sherpa-onnx-cxx-api)

add_executable(online-speech-enhancement-gtcrn-cxx-api
               ./online-speech-enhancement-gtcrn-cxx-api.cc)
target_link_libraries(online-speech-enhancement-gtcrn-cxx-api
                      sherpa-onnx-cxx-api)

add_executable(online-speech-enhancement-dpdfnet-cxx-api
               ./online-speech-enhancement-dpdfnet-cxx-api.cc)
target_link_libraries(online-speech-enhancement-dpdfnet-cxx-api
                      sherpa-onnx-cxx-api)

add_executable(kws-cxx-api ./kws-cxx-api.cc)
target_link_libraries(kws-cxx-api sherpa-onnx-cxx-api)

add_executable(audio-tagging-ced-cxx-api ./audio-tagging-ced-cxx-api.cc)
target_link_libraries(audio-tagging-ced-cxx-api sherpa-onnx-cxx-api)

add_executable(audio-tagging-zipformer-cxx-api ./audio-tagging-zipformer-cxx-api.cc)
target_link_libraries(audio-tagging-zipformer-cxx-api sherpa-onnx-cxx-api)

add_executable(streaming-zipformer-rtf-cxx-api ./streaming-zipformer-rtf-cxx-api.cc)
target_link_libraries(streaming-zipformer-rtf-cxx-api sherpa-onnx-cxx-api)

add_executable(streaming-t-one-ctc-cxx-api   streaming-t-one-ctc-cxx-api.cc)
target_link_libraries(streaming-t-one-ctc-cxx-api sherpa-onnx-cxx-api)

add_executable(whisper-cxx-api ./whisper-cxx-api.cc)
target_link_libraries(whisper-cxx-api sherpa-onnx-cxx-api)

add_executable(fire-red-asr-cxx-api ./fire-red-asr-cxx-api.cc)
target_link_libraries(fire-red-asr-cxx-api sherpa-onnx-cxx-api)

add_executable(fire-red-asr-ctc-cxx-api ./fire-red-asr-ctc-cxx-api.cc)
target_link_libraries(fire-red-asr-ctc-cxx-api sherpa-onnx-cxx-api)

add_executable(moonshine-cxx-api ./moonshine-cxx-api.cc)
target_link_libraries(moonshine-cxx-api sherpa-onnx-cxx-api)

add_executable(moonshine-v2-cxx-api ./moonshine-v2-cxx-api.cc)
target_link_libraries(moonshine-v2-cxx-api sherpa-onnx-cxx-api)

add_executable(sense-voice-cxx-api ./sense-voice-cxx-api.cc)
target_link_libraries(sense-voice-cxx-api sherpa-onnx-cxx-api)

add_executable(wenet-ctc-cxx-api ./wenet-ctc-cxx-api.cc)
target_link_libraries(wenet-ctc-cxx-api sherpa-onnx-cxx-api)

add_executable(omnilingual-asr-ctc-cxx-api ./omnilingual-asr-ctc-cxx-api.cc)
target_link_libraries(omnilingual-asr-ctc-cxx-api sherpa-onnx-cxx-api)

add_executable(medasr-ctc-cxx-api ./medasr-ctc-cxx-api.cc)
target_link_libraries(medasr-ctc-cxx-api sherpa-onnx-cxx-api)

add_executable(nemo-canary-cxx-api ./nemo-canary-cxx-api.cc)
target_link_libraries(nemo-canary-cxx-api sherpa-onnx-cxx-api)

add_executable(cohere-transcribe-cxx-api ./cohere-transcribe-cxx-api.cc)
target_link_libraries(cohere-transcribe-cxx-api sherpa-onnx-cxx-api)

add_executable(offline-punctuation-cxx-api ./offline-punctuation-cxx-api.cc)
target_link_libraries(offline-punctuation-cxx-api sherpa-onnx-cxx-api)

add_executable(online-punctuation-cxx-api ./online-punctuation-cxx-api.cc)
target_link_libraries(online-punctuation-cxx-api sherpa-onnx-cxx-api)

if(SHERPA_ONNX_ENABLE_PORTAUDIO)
  add_executable(sense-voice-simulate-streaming-microphone-cxx-api
    ./sense-voice-simulate-streaming-microphone-cxx-api.cc
    ${CMAKE_CURRENT_LIST_DIR}/../sherpa-onnx/csrc/microphone.cc
  )
  target_link_libraries(sense-voice-simulate-streaming-microphone-cxx-api
    sherpa-onnx-cxx-api
    portaudio_static
  )

  add_executable(fire-red-asr-ctc-simulate-streaming-microphone-cxx-api
    ./fire-red-asr-ctc-simulate-streaming-microphone-cxx-api.cc
    ${CMAKE_CURRENT_LIST_DIR}/../sherpa-onnx/csrc/microphone.cc
  )
  target_link_libraries(fire-red-asr-ctc-simulate-streaming-microphone-cxx-api
    sherpa-onnx-cxx-api
    portaudio_static
  )

  add_executable(wenet-ctc-simulate-streaming-microphone-cxx-api
    ./wenet-ctc-simulate-streaming-microphone-cxx-api.cc
    ${CMAKE_CURRENT_LIST_DIR}/../sherpa-onnx/csrc/microphone.cc
  )
  target_link_libraries(wenet-ctc-simulate-streaming-microphone-cxx-api
    sherpa-onnx-cxx-api
    portaudio_static
  )

  add_executable(parakeet-tdt-simulate-streaming-microphone-cxx-api
    ./parakeet-tdt-simulate-streaming-microphone-cxx-api.cc
    ${CMAKE_CURRENT_LIST_DIR}/../sherpa-onnx/csrc/microphone.cc
  )
  target_link_libraries(parakeet-tdt-simulate-streaming-microphone-cxx-api
    sherpa-onnx-cxx-api
    portaudio_static
  )

  add_executable(parakeet-tdt-ctc-simulate-streaming-microphone-cxx-api
    ./parakeet-tdt-ctc-simulate-streaming-microphone-cxx-api.cc
    ${CMAKE_CURRENT_LIST_DIR}/../sherpa-onnx/csrc/microphone.cc
  )
  target_link_libraries(parakeet-tdt-ctc-simulate-streaming-microphone-cxx-api
    sherpa-onnx-cxx-api
    portaudio_static
  )

  add_executable(zipformer-ctc-simulate-streaming-microphone-cxx-api
    ./zipformer-ctc-simulate-streaming-microphone-cxx-api.cc
    ${CMAKE_CURRENT_LIST_DIR}/../sherpa-onnx/csrc/microphone.cc
  )
  target_link_libraries(zipformer-ctc-simulate-streaming-microphone-cxx-api
    sherpa-onnx-cxx-api
    portaudio_static
  )

  add_executable(zipformer-transducer-simulate-streaming-microphone-cxx-api
    ./zipformer-transducer-simulate-streaming-microphone-cxx-api.cc
    ${CMAKE_CURRENT_LIST_DIR}/../sherpa-onnx/csrc/microphone.cc
  )
  target_link_libraries(zipformer-transducer-simulate-streaming-microphone-cxx-api
    sherpa-onnx-cxx-api
    portaudio_static
  )
endif()

if(SHERPA_ONNX_HAS_ALSA)
  add_executable(sense-voice-simulate-streaming-alsa-cxx-api
    ./sense-voice-simulate-streaming-alsa-cxx-api.cc
    ${CMAKE_CURRENT_LIST_DIR}/../sherpa-onnx/csrc/alsa.cc
  )
  target_link_libraries(sense-voice-simulate-streaming-alsa-cxx-api
    sherpa-onnx-cxx-api
  )

  add_executable(fire-red-asr-ctc-simulate-streaming-alsa-cxx-api
    ./fire-red-asr-ctc-simulate-streaming-alsa-cxx-api.cc
    ${CMAKE_CURRENT_LIST_DIR}/../sherpa-onnx/csrc/alsa.cc
  )
  target_link_libraries(fire-red-asr-ctc-simulate-streaming-alsa-cxx-api
    sherpa-onnx-cxx-api
  )

  add_executable(zipformer-ctc-simulate-streaming-alsa-cxx-api
    ./zipformer-ctc-simulate-streaming-alsa-cxx-api.cc
    ${CMAKE_CURRENT_LIST_DIR}/../sherpa-onnx/csrc/alsa.cc
  )
  target_link_libraries(zipformer-ctc-simulate-streaming-alsa-cxx-api
    sherpa-onnx-cxx-api
  )

  if(DEFINED ENV{SHERPA_ONNX_ALSA_LIB_DIR})
    target_link_libraries(sense-voice-simulate-streaming-alsa-cxx-api -L$ENV{SHERPA_ONNX_ALSA_LIB_DIR} -lasound)
    target_link_libraries(fire-red-asr-ctc-simulate-streaming-alsa-cxx-api -L$ENV{SHERPA_ONNX_ALSA_LIB_DIR} -lasound)
    target_link_libraries(zipformer-ctc-simulate-streaming-alsa-cxx-api -L$ENV{SHERPA_ONNX_ALSA_LIB_DIR} -lasound)
  else()
    target_link_libraries(sense-voice-simulate-streaming-alsa-cxx-api asound)
    target_link_libraries(fire-red-asr-ctc-simulate-streaming-alsa-cxx-api asound)
    target_link_libraries(zipformer-ctc-simulate-streaming-alsa-cxx-api asound)
  endif()
endif()

add_executable(sense-voice-with-hr-cxx-api ./sense-voice-with-hr-cxx-api.cc)
target_link_libraries(sense-voice-with-hr-cxx-api sherpa-onnx-cxx-api)

add_executable(dolphin-ctc-cxx-api ./dolphin-ctc-cxx-api.cc)
target_link_libraries(dolphin-ctc-cxx-api sherpa-onnx-cxx-api)

add_executable(vad-cxx-api ./vad-cxx-api.cc)
target_link_libraries(vad-cxx-api sherpa-onnx-cxx-api)

add_executable(funasr-nano-cxx-api ./funasr-nano-cxx-api.cc)
target_link_libraries(funasr-nano-cxx-api sherpa-onnx-cxx-api)

add_executable(qwen3-asr-cxx-api ./qwen3-asr-cxx-api.cc)
target_link_libraries(qwen3-asr-cxx-api sherpa-onnx-cxx-api)

if(SHERPA_ONNX_ENABLE_TTS)
  add_executable(matcha-tts-zh-cxx-api ./matcha-tts-zh-cxx-api.cc)
  target_link_libraries(matcha-tts-zh-cxx-api sherpa-onnx-cxx-api)

  add_executable(matcha-tts-en-cxx-api ./matcha-tts-en-cxx-api.cc)
  target_link_libraries(matcha-tts-en-cxx-api sherpa-onnx-cxx-api)

  add_executable(kokoro-tts-en-cxx-api ./kokoro-tts-en-cxx-api.cc)
  target_link_libraries(kokoro-tts-en-cxx-api sherpa-onnx-cxx-api)

  add_executable(kitten-tts-en-cxx-api ./kitten-tts-en-cxx-api.cc)
  target_link_libraries(kitten-tts-en-cxx-api sherpa-onnx-cxx-api)

  add_executable(pocket-tts-en-cxx-api ./pocket-tts-en-cxx-api.cc)
  target_link_libraries(pocket-tts-en-cxx-api sherpa-onnx-cxx-api)

  add_executable(kokoro-tts-zh-en-cxx-api ./kokoro-tts-zh-en-cxx-api.cc)
  target_link_libraries(kokoro-tts-zh-en-cxx-api sherpa-onnx-cxx-api)

  add_executable(supertonic-tts-en-cxx-api ./supertonic-tts-en-cxx-api.cc)
  target_link_libraries(supertonic-tts-en-cxx-api sherpa-onnx-cxx-api)

  add_executable(zipvoice-tts-zh-en-cxx-api ./zipvoice-tts-zh-en-cxx-api.cc)
  target_link_libraries(zipvoice-tts-zh-en-cxx-api sherpa-onnx-cxx-api)
endif()
